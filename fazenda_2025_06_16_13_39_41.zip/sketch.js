function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}// Variáveis do Jogo (mantêm-se as mesmas)
let player;
let tileSize = 40;
let gameWidth = 800 ;
let gameHeight = 600;

const GAME_STATE = {
    FIELD: 'field',
    CITY: 'city'
};
let currentGameState = GAME_STATE.FIELD;

let farmTiles = [];
let rows, cols;

// --- NOVAS VARIÁVEIS PARA CUSTO E TEMPO DE PLANTAS ---
const PLANT_TYPES = {
    FOOD: { name: "Comida", seedCost: 5, sellPrice: 10, growthTime: 300, color: [0, 200, 0] },
    CARROT: { name: "Cenoura", seedCost: 15, sellPrice: 30, growthTime: 500, color: [255, 165, 0] }, // Laranja
    PUMPKIN: { name: "Abóbora", seedCost: 50, sellPrice: 100, growthTime: 900, color: [255, 140, 0] }  // Laranja mais escuro
};
// --- FIM NOVAS VARIÁVEIS ---


// Personagem (mantém-se o mesmo)
class Player {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.speed = 5;
        this.inventory = {
            food:0 ,
            carrot: 0, // Novo item no inventário
            pumpkin: 0, // Novo item no inventário
            seeds: { // Agora um objeto para diferentes sementes
                food: 5,
                carrot: 0,
                pumpkin: 0
            }
        };
        this.money = 0;
    }

    display() {
        fill(0, 150, 255);2
        rect(this.x, this.y, tileSize * 0.8, tileSize * 0.8);
    }

    move() {
        if (keyIsDown(LEFT_ARROW)) {
            this.x -= this.speed;
        }
        if (keyIsDown(RIGHT_ARROW)) {
            this.x += this.speed;
        }
        if (keyIsDown(UP_ARROW)) {
            this.y -= this.speed;
        }
        if (keyIsDown(DOWN_ARROW)) {
            this.y += this.speed;
        }

        this.x = constrain(this.x, 0, gameWidth - tileSize * 0.8);
        this.y = constrain(this.y, 0, gameHeight - tileSize * 0.8);
    }
}

// Tile do Campo (MODIFICADO)
class FarmTile {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.isPlanted = false;
        this.plantType = null; // Armazena o tipo de planta (FOOD, CARROT, PUMPKIN)
        this.growthStage = 0; // 0: nada, 1: semente, 2: pequeno, 3: médio, 4: pronto
        this.growthTimer = 0; // Tempo para crescer
        this.maxGrowthTime = 0; // Tempo máximo de crescimento para a planta específica
    }

    display() {
        stroke(50);
        if (this.isPlanted) {
            let baseColor;
            if (this.plantType === PLANT_TYPES.FOOD) {
                baseColor = PLANT_TYPES.FOOD.color;
            } else if (this.plantType === PLANT_TYPES.CARROT) {
                baseColor = PLANT_TYPES.CARROT.color;
            } else if (this.plantType === PLANT_TYPES.PUMPKIN) {
                baseColor = PLANT_TYPES.PUMPKIN.color;
            } else {
                baseColor = [100, 70, 0]; // Cor padrão se algo der errado
            }

            if (this.growthStage === 0) {
                fill(100, 70, 0); // Terra
            } else if (this.growthStage === 1) {
                fill(baseColor[0] * 0.5, baseColor[1] * 0.5, baseColor[2] * 0.5); // Semente (mais escura)
            } else if (this.growthStage === 2) {
                fill(baseColor[0] * 0.7, baseColor[1] * 0.7, baseColor[2] * 0.7); // Planta pequena
            } else if (this.growthStage === 3) {
                fill(baseColor[0] * 0.9, baseColor[1] * 0.9, baseColor[2] * 0.9); // Planta média
            } else if (this.growthStage === 4) {
                fill(baseColor[0], baseColor[1], baseColor[2]); // Planta pronta para colher (cor original)
            }
        } else {
            fill(100, 70, 0); // Terra não plantada
        }
        rect(this.x, this.y, tileSize, tileSize);
    }

    update() {
        if (this.isPlanted && this.growthStage < 4) {
            this.growthTimer++;
            if (this.growthTimer >= this.maxGrowthTime / 4 && this.growthStage < 1) {
                this.growthStage = 1;
            } else if (this.growthTimer >= this.maxGrowthTime / 2 && this.growthStage < 2) {
                this.growthStage = 2;
            } else if (this.growthTimer >= this.maxGrowthTime * 3 / 4 && this.growthStage < 3) {
                this.growthStage = 3;
            } else if (this.growthTimer >= this.maxGrowthTime && this.growthStage < 4) {
                this.growthStage = 4; // Pronto para colher
            }
        }
    }
}

function setup() {
    createCanvas(gameWidth, gameHeight);
    player = new Player(width / 2 - tileSize / 2, height / 2 - tileSize / 2);

    rows = floor(gameHeight / tileSize);
    cols = floor(gameWidth / tileSize);

    for (let i = 0; i < rows; i++) {
        farmTiles[i] = [];
        for (let j = 0; j < cols; j++) {
            farmTiles[i][j] = new FarmTile(j * tileSize, i * tileSize);
        }
    }
}

function draw() {
    background(220);

    if (currentGameState === GAME_STATE.FIELD) {
        drawField();
    } else if (currentGameState === GAME_STATE.CITY) {
        drawCity();
    }

    player.move();
    player.display();
    displayUI();
}

function drawField() {
    for (let i = 0; i < rows; i++) {
        for (let j = 0; j < cols; j++) {
            farmTiles[i][j].display();
            farmTiles[i][j].update();
        }
    }

    fill(150, 150, 150, 150);
    rect(gameWidth * 0.8, 0, gameWidth * 0.2, gameHeight);

    fill(0);
    textSize(16);
    textAlign(CENTER, CENTER);
    text("Ir para a Cidade (Enter)", gameWidth * 0.9, gameHeight / 2);

    if (player.x > gameWidth * 0.8 && player.y < gameHeight && player.y > 0) {
        if (keyIsDown(ENTER)) {
            currentGameState = GAME_STATE.CITY;
            player.x = 10;
        }
    }
}

// drawCity (MODIFICADO)
function drawCity() {
    background(180, 180, 180);

    fill(100);
    rect(width * 0.1, height * 0.3, width * 0.2, height * 0.5);
    rect(width * 0.4, height * 0.2, width * 0.15, height * 0.6);
    rect(width * 0.7, height * 0.4, width * 0.18, height * 0.4);

    // Área para vender comida
    fill(0, 100, 0, 150);
    rect(width * 0.5 - tileSize, height * 0.7, tileSize * 2, tileSize * 1.5);
    fill(255);
    textSize(20);
    text("Banca de Vendas", width * 0.5, height * 0.8);
    textSize(14);
    textAlign(CENTER, CENTER);
    text("Pressione 'S' para Vender Tudo", width * 0.5, height * 0.85);

    // --- Lógica para Vender Tudo ---
    if (dist(player.x, player.y, width * 0.5, height * 0.7 + tileSize) < tileSize * 2 && keyIsDown(83)) { // 'S' key
        if (player.inventory.food > 0) {
            player.money += player.inventory.food * PLANT_TYPES.FOOD.sellPrice;
            player.inventory.food = 0;
            console.log("Comida vendida! Dinheiro atual: " + player.money);
        }
        if (player.inventory.carrot > 0) {
            player.money += player.inventory.carrot * PLANT_TYPES.CARROT.sellPrice;
            player.inventory.carrot = 0;
            console.log("Cenoura vendida! Dinheiro atual: " + player.money);
        }
        if (player.inventory.pumpkin > 0) {
            player.money += player.inventory.pumpkin * PLANT_TYPES.PUMPKIN.sellPrice;
            player.inventory.pumpkin = 0;
            console.log("Abóbora vendida! Dinheiro atual: " + player.money);
        }
    }

    // --- LOJA DE SEMENTES (MODIFICADA) ---
    fill(139, 69, 19, 150);
    rect(width * 0.1, height * 0.05, tileSize * 2.5, tileSize * 3.5); // Aumenta o tamanho para mais itens
    fill(255);
    textSize(20);
    text("Loja de Sementes", width * 0.1 + tileSize * 1.25, height * 0.1);
    textSize(14);
    textAlign(LEFT, TOP);
    text("Semente de Comida: $" + PLANT_TYPES.FOOD.seedCost + " (Pressione '1')", width * 0.1 + 10, height * 0.2);
    text("Semente de Cenoura: $" + PLANT_TYPES.CARROT.seedCost + " (Pressione '2')", width * 0.1 + 10, height * 0.25);
    text("Semente de Abóbora: $" + PLANT_TYPES.PUMPKIN.seedCost + " (Pressione '3')", width * 0.1 + 10, height * 0.3);
    textAlign(CENTER, CENTER); // Retorna para o alinhamento padrão

    // --- Lógica para Comprar Sementes (MODIFICADA) ---
    const shopX = width * 0.1 + tileSize * 1.25;
    const shopY = height * 0.05 + tileSize;

    if (dist(player.x, player.y, shopX, shopY) < tileSize * 2) {
        // Comprar Semente de Comida (tecla '1')
        if (keyIsDown(49)) { // ASCII para '1'
            if (player.money >= PLANT_TYPES.FOOD.seedCost) {
                player.money -= PLANT_TYPES.FOOD.seedCost;
                player.inventory.seeds.food++;
                console.log("Semente de Comida comprada! Dinheiro: " + player.money);
            } else {
                console.log("Dinheiro insuficiente para semente de comida!");
            }
        }
        // Comprar Semente de Cenoura (tecla '2')
        if (keyIsDown(50)) { // ASCII para '2'
            if (player.money >= PLANT_TYPES.CARROT.seedCost) {
                player.money -= PLANT_TYPES.CARROT.seedCost;
                player.inventory.seeds.carrot++;
                console.log("Semente de Cenoura comprada! Dinheiro: " + player.money);
            } else {
                console.log("Dinheiro insuficiente para semente de cenoura!");
            }
        }
        // Comprar Semente de Abóbora (tecla '3')
        if (keyIsDown(51)) { // ASCII para '3'
            if (player.money >= PLANT_TYPES.PUMPKIN.seedCost) {
                player.money -= PLANT_TYPES.PUMPKIN.seedCost;
                player.inventory.seeds.pumpkin++;
                console.log("Semente de Abóbora comprada! Dinheiro: " + player.money);
            } else {
                console.log("Dinheiro insuficiente para semente de abóbora!");
            }
        }
    }
    // --- FIM DA LÓGICA DE COMPRA ---

    fill(100, 70, 0, 150);
    rect(0, 0, gameWidth * 0.2, gameHeight);

    fill(0);
    textSize(16);
    textAlign(CENTER, CENTER);
    text("Ir para o Campo (Enter)", gameWidth * 0.1, gameHeight / 2);

    if (player.x < gameWidth * 0.2 && player.y < gameHeight && player.y > 0) {
        if (keyIsDown(ENTER)) {
            currentGameState = GAME_STATE.FIELD;
            player.x = gameWidth - tileSize * 0.8 - 10;
        }
    }
}

// displayUI (MODIFICADO)
function displayUI() {
    fill(0);
    textSize(16);
    textAlign(LEFT, TOP);
    text("Dinheiro: $" + player.money, 10, 10);
    text("Sementes:", 10, 30);
    text("  Comida: " + player.inventory.seeds.food, 25, 50);
    text("  Cenoura: " + player.inventory.seeds.carrot, 25, 70);
    text("  Abóbora: " + player.inventory.seeds.pumpkin, 25, 90);
    text("Colheita:", 10, 120);
    text("  Comida: " + player.inventory.food, 25, 140);
    text("  Cenoura: " + player.inventory.carrot, 25, 160);
    text("  Abóbora: " + player.inventory.pumpkin, 25, 180);
    text("Local: " + (currentGameState === GAME_STATE.FIELD ? "Campo" : "Cidade"), 10, 200);
}

// keyPressed (MODIFICADO)
function keyPressed() {
    if (currentGameState === GAME_STATE.FIELD) {
        let playerGridX = floor(player.x / tileSize);
        let playerGridY = floor(player.y / tileSize);

        if (playerGridY >= 0 && playerGridY < rows && playerGridX >= 0 && playerGridX < cols) {
            let currentTile = farmTiles[playerGridY][playerGridX];

            // --- PLANTAR (TECLAS '1', '2', '3') ---
            if (keyCode === 49) { // '1' para Comida
                if (!currentTile.isPlanted && player.inventory.seeds.food > 0) {
                    currentTile.isPlanted = true;
                    currentTile.plantType = PLANT_TYPES.FOOD;
                    currentTile.maxGrowthTime = PLANT_TYPES.FOOD.growthTime;
                    currentTile.growthStage = 1;
                    currentTile.growthTimer = 0;
                    player.inventory.seeds.food--;
                    console.log("Semente de Comida plantada!");
                } else if (player.inventory.seeds.food === 0) {
                    console.log("Você não tem sementes de Comida!");
                } else {
                    console.log("Este tile já está plantado!");
                }
            } else if (keyCode === 50) { // '2' para Cenoura
                if (!currentTile.isPlanted && player.inventory.seeds.carrot > 0) {
                    currentTile.isPlanted = true;
                    currentTile.plantType = PLANT_TYPES.CARROT;
                    currentTile.maxGrowthTime = PLANT_TYPES.CARROT.growthTime;
                    currentTile.growthStage = 1;
                    currentTile.growthTimer = 0;
                    player.inventory.seeds.carrot--;
                    console.log("Semente de Cenoura plantada!");
                } else if (player.inventory.seeds.carrot === 0) {
                    console.log("Você não tem sementes de Cenoura!");
                } else {
                    console.log("Este tile já está plantado!");
                }
            } else if (keyCode === 51) { // '3' para Abóbora
                if (!currentTile.isPlanted && player.inventory.seeds.pumpkin > 0) {
                    currentTile.isPlanted = true;
                    currentTile.plantType = PLANT_TYPES.PUMPKIN;
                    currentTile.maxGrowthTime = PLANT_TYPES.PUMPKIN.growthTime;
                    currentTile.growthStage = 1;
                    currentTile.growthTimer = 0;
                    player.inventory.seeds.pumpkin--;
                    console.log("Semente de Abóbora plantada!");
                } else if (player.inventory.seeds.pumpkin === 0) {
                    console.log("Você não tem sementes de Abóbora!");
                } else {
                    console.log("Este tile já está plantado!");
                }
            }

            // --- COLHER (TECLA 'C') ---
            if (keyCode === 67) { // 'C'
                if (currentTile.isPlanted && currentTile.growthStage === 4) {
                    if (currentTile.plantType === PLANT_TYPES.FOOD) {
                        player.inventory.food++;
                    } else if (currentTile.plantType === PLANT_TYPES.CARROT) {
                        player.inventory.carrot++;
                    } else if (currentTile.plantType === PLANT_TYPES.PUMPKIN) {
                        player.inventory.pumpkin++;
                    }
                    currentTile.isPlanted = false;
                    currentTile.plantType = null;
                    currentTile.growthStage = 0;
                    currentTile.growthTimer = 0;
                    currentTile.maxGrowthTime = 0;
                    console.log("Colheita realizada!");
                } else if (currentTile.isPlanted && currentTile.growthStage < 4) {
                    console.log("A planta ainda não está pronta para colher.");
                } else {
                    console.log("Não há nada para colher aqui.");
                }
            }
        }
    }
}